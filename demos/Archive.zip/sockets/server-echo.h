#pragma once


static void start_server();
static void process_requests(int listen_socket);