#pragma once

#include <stdint.h>
#include "protocol.h"

static void start_client(proto_msg_t *send_msg, proto_msg_t *recv_message);
