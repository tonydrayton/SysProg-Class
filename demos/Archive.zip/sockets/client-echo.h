#pragma once

#include <stdint.h>

static void start_client(uint8_t *packet_buff);
